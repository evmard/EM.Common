﻿using $rootnamespace$.Entities;
using MicroServiceBase.Contract;

namespace $rootnamespace$
{
    public class $safeitemname$ : RpcContractInfo<TReqest, TResult>
    {
        public override string QueueName { get { return GetQueueName(GetType()); } }
        public static string GetQueueName()
        {
            return GetQueueName(typeof($safeitemname$));
        }
    }
}
