﻿using MicroServiceBase.Contract;

namespace $rootnamespace$
{
    public class $safeitemname$ : JsonSerializable<$safeitemname$>, IResponce
    {
        public string ErrorMsg { get; set; }
        
    }
}